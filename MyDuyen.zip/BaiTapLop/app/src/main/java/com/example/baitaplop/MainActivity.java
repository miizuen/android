
package com.example.baitaplop;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmail109, etPassword109;
    private Button btnLogin109;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail109 = findViewById(R.id.etEmail109);
        etPassword109 = findViewById(R.id.etPassword109);
        btnLogin109 = findViewById(R.id.btnLogin109);

        btnLogin109.setOnClickListener(v -> {
            String email = etEmail109.getText().toString().trim();
            String password = etPassword109.getText().toString().trim();

            // Kiểm tra username và password
            if (email.equalsIgnoreCase("dmy61151@gmail.com") && password.equals("123456")) {
                // Nếu đúng thì chuyển sang SecondActivity và gửi dữ liệu
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("fullname", "Bach Ngoc My Duyen");
                intent.putExtra("codestudent", "23115053122109");
                intent.putExtra("phone", "+84 947530167");
                startActivity(intent);

                // Thông báo thành công
                Toast.makeText(MainActivity.this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
            } else {
                // Sai email hoặc mật khẩu
                Toast.makeText(MainActivity.this, "Sai tài khoản hoặc mật khẩu", Toast.LENGTH_SHORT).show();
            }
        });
    }
}