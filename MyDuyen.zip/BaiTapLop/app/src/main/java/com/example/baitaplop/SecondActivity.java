package com.example.baitaplop;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView txtProfileName109, back109;
    private EditText etEmail109, etFullName109, etMsv109, etPhone109;
    private ImageView imvSetting109;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtProfileName109 = findViewById(R.id.txt_Profile_109);
        back109 = findViewById(R.id.back_109);
        imvSetting109 = findViewById(R.id.imvsetting_109);

        etEmail109 = findViewById(R.id.etEmail109);
        etFullName109 = findViewById(R.id.etFullName109);
        etMsv109 = findViewById(R.id.etMsv109);
        etPhone109 = findViewById(R.id.etPhone109);

        Intent intent = getIntent();
        String email = intent.getStringExtra("email");
        String fullname = intent.getStringExtra("fullname");
        String codestudent = intent.getStringExtra("codestudent");
        String phone = intent.getStringExtra("phone");

        etEmail109.setText(email != null ? email : "");

        if (fullname != null && !fullname.isEmpty()) {
            txtProfileName109.setText(fullname);
            etFullName109.setText(fullname);
            etMsv109.setText(codestudent);
            etPhone109.setText(phone);
        } else {
            String profileName = "";
            if (email != null && email.contains("@")) {
                profileName = email.substring(0, email.indexOf("@"));
            }
            txtProfileName109.setText(profileName);
            etFullName109.setText("");
            etMsv109.setText("");
            etPhone109.setText("");
        }
        imvSetting109.setOnClickListener(v -> {
            Intent i = new Intent(SecondActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });

        back109.setOnClickListener(v -> {
            Intent i = new Intent(SecondActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }
}
